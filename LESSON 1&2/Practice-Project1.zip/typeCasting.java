package TypeCasting;

public class typeCasting {

	public static void main(String[] args) {
		char charvalue='A';
		int intValue=charvalue;
		System.out.println("IMPLICIT type casting from cahracter to int:"); 
		System.out.println("Character Value: "+charvalue);
		System.out.println("Int value: "+intValue);  
		
		//Implicit casting from int to long value
		float floatValue = intValue; 
		System.out.println("IMPLICIT type casting from int to float:");
	    System.out.println("int value: " + intValue);
		System.out.println("float value: " + floatValue);
		    
	
	   // Explicit casting from double to int
	
	    double db = 65.2;
	    int iv = (int) db; 
	    System.out.println("EXPLICIT  type casting from double to int:");
	    System.out.println("double value: " + db);
	    System.out.println("int value: " + iv);
	    
	    char cv=(char)iv;
	    System.out.println("EXPLICIT type casting from int to char");
	    System.out.println("int value: " + iv);
	    System.out.println("character value: " +cv);
	}
}