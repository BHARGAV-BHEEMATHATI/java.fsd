package collections;


	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;

	public class CollectionsExample {

	    public static void main(String[] args) {
	        // Creating an ArrayList to store student names
	        List<String> studentNames = new ArrayList<>();

	        // Adding names to the ArrayList
	        studentNames.add("John");
	        studentNames.add("Jane");
	        studentNames.add("Bob");

	        // Displaying the list of student names
	        System.out.println("Student Names:");
	        for (String name : studentNames) {
	            System.out.println(name);
	        }

	        // Creating a HashMap to store student grades
	        Map<String, Double> studentGrades = new HashMap<>();

	        // Adding grades to the HashMap
	        studentGrades.put("John", 90.5);
	        studentGrades.put("Jane", 85.0);
	        studentGrades.put("Bob", 88.5);

	        // Displaying the grades of students
	        System.out.println("\nStudent Grades:");
	        for (Map.Entry<String, Double> entry : studentGrades.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }
	    }
	}


