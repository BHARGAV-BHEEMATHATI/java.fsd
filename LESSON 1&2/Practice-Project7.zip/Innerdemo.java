package innerClass;
public class Innerdemo {

    // Outer class variable
    private int demovalue = 10;

    // Inner class
    public class Inner {
        // Inner class variable
        private int innerValue = 5;

        // Inner class method
        public void displayValues() {
            System.out.println("Outer Value: " + demovalue);
            System.out.println("Inner Value: " + innerValue);
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the Outer class
        Innerdemo outerObject = new Innerdemo();

        // Creating an instance of the Inner class using the outerObject
        Innerdemo.Inner innerObject = outerObject.new Inner();

        // Calling the displayValues method of the Inner class
        innerObject.displayValues();
    }
}



