import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/WelcomeWithHiddenFields")
public class WelcomeWithHiddenFields extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve session ID from the hidden form field
        String sessionId = request.getParameter("sessionid");

        out.println("<html><head><title>Welcome with Hidden Form Fields</title></head><body>");
        out.println("<h1>Welcome with Hidden Form Fields</h1>");
        out.println("<p>Session ID: " + sessionId + "</p>");
        out.println("<p>Session handled with hidden form fields.</p>");
        out.println("</body></html>");
    }
}

