import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    
@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve session ID from the URL
        String sessionId = request.getParameter("sessionid");

        HttpSession session = request.getSession(false);
        if (session != null && sessionId.equals(session.getId())) {
            out.println("<html><head><title>Welcome with URL Rewriting</title></head><body>");
            out.println("<h1>Welcome with URL Rewriting</h1>");
            out.println("<p>Session handled with URL rewriting.</p>");
            out.println("</body></html>");
        } else {
            out.println("Invalid session ID");
        }
    }
}
