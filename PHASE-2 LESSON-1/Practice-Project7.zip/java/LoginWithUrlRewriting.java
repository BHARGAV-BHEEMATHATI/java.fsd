import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginWithUrlRewriting")
public class LoginWithUrlRewriting extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("admin".equals(username) && "password".equals(password)) {
            HttpSession session = request.getSession();
            String sessionId = session.getId();

            // Append session ID to the URL
            String redirectUrl = "Welcome?sessionid=" + sessionId;

            // Redirect with URL rewriting
            response.sendRedirect(redirectUrl);
        } else {
            out.println("Invalid credentials");
        }
    }
}

