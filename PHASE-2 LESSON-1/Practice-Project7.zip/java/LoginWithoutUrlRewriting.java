import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginWithoutUrlRewriting")
public class LoginWithoutUrlRewriting extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("admin".equals(username) && "password".equals(password)) {
            HttpSession session = request.getSession();
            out.println("<html><head><title>Login Result</title></head><body>");
            out.println("<h1>Login Result</h1>");
            out.println("<p>Session handled without URL rewriting.</p>");
            out.println("</body></html>");
        } else {
            out.println("Invalid credentials");
        }
    }
}
