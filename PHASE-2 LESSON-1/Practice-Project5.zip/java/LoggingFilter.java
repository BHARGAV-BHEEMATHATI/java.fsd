import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class LoggingFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code, if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Log information about the incoming request
        System.out.println("Request received at: " + System.currentTimeMillis());

        // Pass the request and response to the next filter or servlet in the chain
        chain.doFilter(request, response);

        // Log information about the outgoing response
        System.out.println("Response sent at: " + System.currentTimeMillis());
    }

    @Override
    public void destroy() {
        // Cleanup code, if needed
    }
}

