

import java.io.IOException;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

public class MyServlet implements Servlet {
    private ServletConfig servletConfig;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.servletConfig = config;
        System.out.println("Servlet initialized");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response)
            throws ServletException, IOException {
        System.out.println("Processing request...");
        response.getWriter().println("<html><head><title>Servlet Demo</title></head><body>");
        response.getWriter().println("<h1>Hello from MyServlet!</h1>");
        response.getWriter().println("<p>Client IP: " + request.getRemoteAddr() + "</p>");
        response.getWriter().println("<p>User Agent: " + ((HttpServletRequest) request).getHeader("User-Agent") + "</p>");
        response.getWriter().println("</body></html>");
      
    }

    @Override
    public void destroy() {
        System.out.println("Servlet destroyed");
    }

    @Override
    public ServletConfig getServletConfig() {
        return servletConfig;
    }

    @Override
    public String getServletInfo() {
        return "MyServlet";
    }
}
