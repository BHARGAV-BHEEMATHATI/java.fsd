import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class MyServlet implements Servlet {
    private ServletConfig config;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
        System.out.println("Servlet initialized");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response)
            throws ServletException, IOException {
        // Set the content type of the response
        response.setContentType("text/html");

        // Get a PrintWriter object to write HTML to the response
        PrintWriter out = response.getWriter();

        // Write HTML content
        out.println("<html><head><title>MyServlet</title></head><body>");
        out.println("<h1>Hello from MyServlet!</h1>");
        out.println("</body></html>");

        System.out.println("Service method called");
    }

    @Override
    public void destroy() {
        System.out.println("Servlet destroyed");
    }

    @Override
    public ServletConfig getServletConfig() {
        return config;
    }

    @Override
    public String getServletInfo() {
        return "MyServlet";
    }
}

