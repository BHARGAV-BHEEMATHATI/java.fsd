

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class PostHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public PostHandler() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String data = request.getParameter("data");

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        out.println("<html>");
	        out.println("<head><title>POST Handler</title></head>");
	        out.println("<body>");
	        out.println("<h1>POST Handler</h1>");
	        out.println("<p>Data received from POST request: " + data + "</p>");
	        out.println("</body>");
	        out.println("</html>");
	
	}

}
