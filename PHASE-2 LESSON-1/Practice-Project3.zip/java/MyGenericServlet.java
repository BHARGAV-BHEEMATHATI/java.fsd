

import java.io.IOException;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;


@WebServlet("/MyGenericServlet")
public class MyGenericServlet extends GenericServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void service(ServletRequest request, ServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        String clientIP = request.getRemoteAddr();
        String userAgent = ((HttpServletRequest) request).getHeader("User-Agent");
        // Write the response
        response.getWriter().println("<html><head><title>Generic Servlet Demo</title></head><body>");
        response.getWriter().println("<h1>Hello from Generic Servlet!</h1>");
        response.getWriter().println("<p>Client IP: " + clientIP + "</p>");
        response.getWriter().println("<p>User Agent: " + userAgent + "</p>");
        response.getWriter().println("</body></html>");
    }
}
