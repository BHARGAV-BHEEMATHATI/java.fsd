import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ServletCookie/LoginWithoutCookie")
public class LoginWithoutCookie extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("user2".equals(username) && "password".equals(password)) {
            out.println("<html><head><title>Login Result</title></head><body>");
            out.println("<h1>Login Result</h1>");
            
            HttpSession session = request.getSession(true);
            out.println("<p>Session handled without cookie.</p>");

            out.println("</body></html>");
        } else {
            out.println("Invalid credentials");
        }
    }
}
