import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ServletCookie/LoginWithCookie")
public class LoginWithCookie extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String rememberMe = request.getParameter("remember");

        if ("user1".equals(username) && "password".equals(password)) {
            out.println("<html><head><title>Login Result</title></head><body>");
            out.println("<h1>Login Result</h1>");
            
            HttpSession session = request.getSession(true);
            if (rememberMe != null) {
                // Create a cookie with the session ID
                Cookie cookie = new Cookie("sessionId", session.getId());
                cookie.setMaxAge(60 * 60 * 24 * 30); // Set cookie expiration to 30 days
                response.addCookie(cookie);
                out.println("<p>Session handled with cookie.</p>");
            } else {
                out.println("<p>Session handled without cookie.</p>");
            }

            out.println("</body></html>");
        } else {
            out.println("Invalid credentials");
        }
    }
}

