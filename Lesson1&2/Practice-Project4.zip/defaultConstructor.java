package constructor;
public class defaultConstructor {
    private int intValue;
    private String stringValue;

    // Method to display the values
    public void displayValues() {
        System.out.println("intValue: " + intValue);
        System.out.println("stringValue: " + stringValue);
    }

    public static void main(String[] args) {
        // Creating an object using the default constructor
       defaultConstructor myObject = new defaultConstructor();
       defaultConstructor myObject2=new defaultConstructor();

        // Displaying the default values
        myObject.displayValues();
        myObject2.displayValues();
    }
}
