package arrays;

public class Array {

	    public static void main(String[] args) {
	    	
	    	
	        // Single-dimensional array
	        int[] singleArray = {1, 2, 3, 4, 5};

	        // Display single-dimensional array
	        System.out.println("Single-dimensional Array:");
	        for (int i = 0; i < singleArray.length; i++) {
	            System.out.println("Element at index " + i + ": " + singleArray[i]);
	        }

	        // Multi-dimensional array (2D array)
	        int[][] multiArray = {{1, 2, 3},{4, 5, 6},{7, 8, 9}};

	        // Display multi-dimensional array
	        System.out.println("\nMulti-dimensional Array (2D Array):");
	        for (int i = 0; i < multiArray.length; i++) {
	            for (int j = 0; j < multiArray[i].length; j++) {
	                System.out.print(multiArray[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	}
