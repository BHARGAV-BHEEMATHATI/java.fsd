package methods;

public class callByValue {
   int a,b,c;
   public void display(int a,int b) {
	   this.a=a;
	   this.b=b;
	   c=a+b;
			  
	   System.out.println("sum of two numbers is :"+c);
	 
   }
   
   public static void main(String[] args) {
	  callByValue dp=new callByValue();
	  dp.display(3, 4);//calling method by value
	   
   }
}
