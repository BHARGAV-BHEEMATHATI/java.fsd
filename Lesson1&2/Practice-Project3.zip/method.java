package methods;

public class method {

	  // Static method for addition
    public static int addStatic(int a, int b) {
        return a + b;
    }

   
    public int subtractInstance(int a, int b) {
        return a - b;
    }
  

    // Method with string data types
    public static String concatenateStrings(String str1, String str2, String str3) {
        return str1 + str2 + str3;
    }

      public static void main(String[] args) {
        
        method md = new method();

        // Calling addition
        int result1 = addStatic(5, 3);
        System.out.println("addition of two static values: " + result1);
    
        // calling subtraction
        int result2 =md.subtractInstance(8, 4);
        System.out.println("subtraction od two values is: " + result2);

      
        // Call a method with string data types
        String combinedString =concatenateStrings("Hello", " ", "World");
        System.out.println("Combined String: " + combinedString);

  
    }
}

