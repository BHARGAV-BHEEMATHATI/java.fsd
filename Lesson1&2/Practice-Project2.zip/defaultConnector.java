package modifiers;

public class defaultConnector {
	public static void main(String[] args) {
        defaultAccessModifier obj = new defaultAccessModifier();
        obj.defaultMethod();//accessing from the another class in the same package
        System.out.println(obj.defaultVariable);
}
}