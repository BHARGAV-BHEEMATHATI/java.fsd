package modifiers;

     class publicDemo {
	    public int a=2,b=5;
	    public int publicVariable = a+b;

	    public void publicMethod() {
	        System.out.println("Public Method");
	        System.out.println("the sum is:"+publicVariable);
	    }
	}

	public class publicAccessModifier {
	    public static void main(String[] args) {
	        publicDemo obj = new publicDemo();
	        obj.publicMethod();
	       
	    }
	}

