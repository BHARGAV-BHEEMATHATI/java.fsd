package modifiers;

public class defaultAccessModifier {
	int a=10,b=25;
	int defaultVariable = a*b;

    void defaultMethod() {
        System.out.println("This is Default Method");
        //the default modifier can access from another class but in same package  so here the main class in another class
     // Compilation error: defaultVariable has default access in defaultAccessModifier and is not accessible from a different package.
    }
}


