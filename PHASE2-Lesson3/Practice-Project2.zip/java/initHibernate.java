import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InitHibernate")
public class initHibernate extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Initialize Hibernate
            HibernateUtil.getSessionFactory();

            // Your additional logic if needed

            response.getWriter().println("Hibernate Initialized Successfully!");
        } catch (Exception ex) {
            throw new ServletException("Failed to initialize Hibernate", ex);
        }
    }
}  