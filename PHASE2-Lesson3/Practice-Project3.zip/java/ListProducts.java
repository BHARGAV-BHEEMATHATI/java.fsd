import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ListProducts")
public class ListProducts extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        SessionFactory factory = null;
        Session session = null;

        try {
            // Use HibernateUtil to get the session factory
            factory = HibernateUtil.getSessionFactory();
            session = factory.getCurrentSession();

            session.beginTransaction();

            // Use Hibernate to fetch and display products
            List<Eproduct> productList = session.createQuery("from Eproduct").getResultList();

            // Generate HTML for product list
            StringBuilder htmlContent = new StringBuilder("<html><head><title>Product List</title></head><body>");
            htmlContent.append("<h1>Product List</h1>");
            htmlContent.append("<table border='1'><tr><th>ID</th><th>Name</th><th>Price</th></tr>");

            for (Eproduct product : productList) {
                htmlContent.append("<tr><td>").append(product.getId()).append("</td>");
                htmlContent.append("<td>").append(product.getName()).append("</td>");
                htmlContent.append("<td>").append(product.getPrice()).append("</td></tr>");
            }

            htmlContent.append("</table></body></html>");

            // Set the HTML content in the response
            response.setContentType("text/html");
            response.getWriter().write(htmlContent.toString());

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (session != null && session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
        } finally {
            // Close the session in a finally block
            if (session != null && session.isOpen()) {
                session.close();
            }
            // close the session factory in a separate try-catch block
            try {
                if (factory != null && !factory.isClosed()) {
                    HibernateUtil.shutdown();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
