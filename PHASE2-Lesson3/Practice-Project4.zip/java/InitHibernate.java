// InitHibernate.java
import org.hibernate.SessionFactory;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class InitHibernate extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        try {
            // Initialize Hibernate
            SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
            System.out.println("Hibernate initialized successfully.");

            // Perform any Hibernate-related operations here

            // Close Hibernate
            sessionFactory.close();
            System.out.println("Hibernate closed successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
