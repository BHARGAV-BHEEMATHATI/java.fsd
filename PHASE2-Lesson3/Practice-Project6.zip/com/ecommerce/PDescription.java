package com.ecommerce;

public class PDescription {
	public String Descrip = "Hello from Description";

	public String getDescrip() {
		return Descrip;
	}

	public void setDescrip(String descrip) {
		Descrip = descrip;
	}
	
	
	
	
	
}
