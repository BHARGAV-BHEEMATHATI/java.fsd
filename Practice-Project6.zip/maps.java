package maps;
	import java.util.HashMap;
	import java.util.Map;

	public class maps {

	    public static void main(String[] args) {
	        // Creating a HashMap to store books and their authors
	        Map<String, String> bookAuthors = new HashMap<>();

	        // Adding entries to the HashMap
	        bookAuthors.put("Java Book", "John Doe");
	        bookAuthors.put("Python Book", "Jane Smith");
	        bookAuthors.put("C++ Book", "Bob Johnson");

	        // Displaying the map entries
	        System.out.println("Books and Authors:");
	        for (Map.Entry<String, String> entry : bookAuthors.entrySet()) {
	            System.out.println(entry.getKey() + " by " + entry.getValue());
	        }

	        // Checking if a specific book is in the map
	        String bookToCheck = "Java Book";
	        if (bookAuthors.containsKey(bookToCheck)) {
	            System.out.println("\n" + bookToCheck + " is present in the map.");
	        } else {
	            System.out.println("\n" + bookToCheck + " is not present in the map.");
	        }

	        // Removing a book from the map
	        String bookToRemove = "Python Book";
	        bookAuthors.remove(bookToRemove);

	        // Displaying the updated map entries
	        System.out.println("\nBooks and Authors (after removal):");
	        for (Map.Entry<String, String> entry : bookAuthors.entrySet()) {
	            System.out.println(entry.getKey() + " by " + entry.getValue());
	        }
	    }
	}

