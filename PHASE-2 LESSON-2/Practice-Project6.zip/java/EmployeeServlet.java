import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Load the MySQL JDBC driver using Class.forName (needed in older JDBC versions)
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static final String DB_URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "new";
    private static final String PASSWORD = "Maneesha@2000";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            if ("insert".equals(action)) {
                insertEmployee(connection, name, age);
            } else if ("update".equals(action)) {
                // Assuming you have an 'id' parameter for the record to update
                int id = Integer.parseInt(request.getParameter("id"));
                updateEmployee(connection, id, name, age);
            } else if ("delete".equals(action)) {
                // Assuming you have an 'id' parameter for the record to delete
                int id = Integer.parseInt(request.getParameter("id"));
                deleteEmployee(connection, id);
            }

            response.sendRedirect("index.html"); // Redirect to the form after processing

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error occurred during database operation!");
        }
    }

    private void insertEmployee(Connection connection, String name, int age) throws SQLException {
        String sqlInsert = "INSERT INTO employee (name, age) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sqlInsert)) {
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.executeUpdate();
        }
    }

    private void updateEmployee(Connection connection, int id, String name, int age) throws SQLException {
        String sqlUpdate = "UPDATE employee SET name=?, age=? WHERE id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sqlUpdate)) {
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setInt(3, id);
            preparedStatement.executeUpdate();
        }
    }

    private void deleteEmployee(Connection connection, int id) throws SQLException {
        String sqlDelete = "DELETE FROM employee WHERE id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sqlDelete)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }
}
