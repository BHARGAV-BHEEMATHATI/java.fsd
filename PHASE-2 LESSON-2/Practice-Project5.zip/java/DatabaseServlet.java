import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DatabaseServlet")
public class DatabaseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    static {
        try {
            // Load the MySQL JDBC driver using Class.forName 
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static final String DB_URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "new";
    private static final String PASSWORD = "Maneesha@2000";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            createDatabase(connection, "testdb");  // Change the database name as needed

            response.setContentType("text/html");
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h2>Database operation completed successfully!</h2>");
            response.getWriter().println("</body></html>");

        } catch (SQLException e) {
            handleSQLException(e, response);
        }
    }

    private void createDatabase(Connection connection, String dbName) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS " + dbName);
        }
    }

    private void handleSQLException(SQLException e, HttpServletResponse response) throws IOException {
        System.err.println("SQL Exception:");

        while (e != null) {
            System.err.println("Error Message: " + e.getMessage());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            e = e.getNextException();
        }

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Error occurred during database operation!</h2>");
        response.getWriter().println("</body></html>");
    }
}
