import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCDemo {

    public static void main(String[] args) {
        // Load the JDBC driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
            return;
        }

        // Rest of your code...
    

        // Step 1: Establish a connection to the database
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "new", "Maneesha@2000")) {

            // Step 2: Create and execute a statement
            String sqlInsert = "INSERT INTO employee (name, age) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlInsert)) {
                preparedStatement.setString(1, "John Doe");
                preparedStatement.setInt(2, 25);
                int rowsAffected = preparedStatement.executeUpdate();
                System.out.println("Rows affected: " + rowsAffected);
            }

            // Step 3: Query the database and retrieve results
            String sqlSelect = "SELECT * FROM employee";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlSelect);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                // Step 4: Process the result set
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("name");
                    int age = resultSet.getInt("age");
                    System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

