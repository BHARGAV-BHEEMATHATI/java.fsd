import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            String name = request.getParameter("name");
            int age = Integer.parseInt(request.getParameter("age"));

            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "new", "Maneesha@2000")) {
                String sqlInsert = "INSERT INTO employee (name, age) VALUES (?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlInsert)) {
                    preparedStatement.setString(1, name);
                    preparedStatement.setInt(2, age);
                    int rowsAffected = preparedStatement.executeUpdate();

                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.println("<html><body>");
                    out.println("<h2>Form submitted successfully!</h2>");
                    out.println("<p>Rows affected: " + rowsAffected + "</p>");
                    out.println("</body></html>");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
