import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "new";
    private static final String PASSWORD = "Maneesha@2000";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load JDBC driver
            
            String name = request.getParameter("name");
            int age = Integer.parseInt(request.getParameter("age"));

            try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
                callInsertEmployeeProcedure(connection, name, age);

                response.setContentType("text/html");
                response.getWriter().println("<html><body>");
                response.getWriter().println("<h2>Form submitted successfully!</h2>");
                response.getWriter().println("</body></html>");

            } catch (SQLException e) {
                handleSQLException(e);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void callInsertEmployeeProcedure(Connection connection, String name, int age) throws SQLException {
        try (CallableStatement callableStatement = connection.prepareCall("{call insert_employee(?, ?)}")) {
            callableStatement.setString(1, name);
            callableStatement.setInt(2, age);
            callableStatement.execute();
        }
    }

    private void handleSQLException(SQLException e) {
        System.err.println("SQL Exception:");

        while (e != null) {
            System.err.println("Error Message: " + e.getMessage());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            e = e.getNextException();
        }
    }
}

