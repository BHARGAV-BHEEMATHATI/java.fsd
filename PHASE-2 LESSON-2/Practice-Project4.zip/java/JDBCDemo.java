import java.sql.*;

public class JDBCDemo {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "new";
    private static final String PASSWORD = "Maneesha@2000";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            // Call stored procedure
            callInsertEmployeeProcedure(connection, "John Doe", 30);

            System.out.println("Stored procedure executed successfully.");

        } catch (SQLException e) {
            handleSQLException(e);
        }
    }

    private static void callInsertEmployeeProcedure(Connection connection, String name, int age) throws SQLException {
        try (CallableStatement callableStatement = connection.prepareCall("{call insert_employee(?, ?)}")) {
            // Set parameters for the stored procedure
            callableStatement.setString(1, name);
            callableStatement.setInt(2, age);

            // Execute the stored procedure
            callableStatement.execute();
        }
    }

    private static void handleSQLException(SQLException e) {
        System.err.println("SQL Exception:");

        while (e != null) {
            System.err.println("Error Message: " + e.getMessage());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            e = e.getNextException();
        }
    }
}
