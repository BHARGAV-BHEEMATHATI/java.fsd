import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class AssertionsTest {

    @Test
    public void testAssertions() {
        // Test equality
        int result1 = Math.addExact(2, 2);
        System.out.println("Result 1: " + result1);
        assertEquals(4, result1);
        
        // Test for true condition
        boolean result2 = 5 > 3;
        System.out.println("Result 2: " + result2);
        assertTrue(result2, "5 is greater than 3");
        
        // Test for false condition
        boolean result3 = 2 == 1;
        System.out.println("Result 3: " + result3);
        assertFalse(result3, "2 is not equal to 1");
        
        // Test for not null
        String str = "Hello, world!";
        System.out.println("Result 4: " + str);
        assertNotNull(str);
        
        // Test for null
        String nullStr = null;
        System.out.println("Result 5: " + nullStr);
        assertNull(nullStr);
        
        // Test for array equality
        int[] expectedArray = new int[] {1, 2, 3};
        int[] actualArray = new int[] {1, 2, 3};
        System.out.println("Result 6: " + java.util.Arrays.toString(actualArray));
        assertArrayEquals(expectedArray, actualArray);
    }
}
