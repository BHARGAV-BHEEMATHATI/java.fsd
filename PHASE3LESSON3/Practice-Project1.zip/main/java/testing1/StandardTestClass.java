package testing1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StandardTestClass {

    @Test
    public void testAddition() {
        int result1 = MathUtils.add(2, 2);
        int result2 = MathUtils.add(5, 5);
        int result3 = MathUtils.add(2, -3);
        
        System.out.println("Result 1: " + result1);
        System.out.println("Result 2: " + result2);
        System.out.println("Result 3: " + result3);
        
        assertEquals(4, result1);
        assertEquals(10, result2);
        assertEquals(-1, result3);
    }
    
    @Test
    public void testSubtraction() {
        int result1 = MathUtils.subtract(5, 2);
        int result2 = MathUtils.subtract(3, 5);
        int result3 = MathUtils.subtract(10, 10);
        
        System.out.println("Result 1: " + result1);
        System.out.println("Result 2: " + result2);
        System.out.println("Result 3: " + result3);
        
        assertEquals(3, result1);
        assertEquals(-2, result2);
        assertEquals(0, result3);
    }
}
