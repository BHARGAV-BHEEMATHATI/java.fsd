import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class RepeatedTestsTest {

    @RepeatedTest(5)
    @DisplayName("Repeated addition test")
    void testRepeatedAddition() {
        Calculator calculator = new Calculator();
        int result = calculator.add(2, 3);
        System.out.println("Result of repeated addition test: " + result);
        assertTrue(result == 5);
    }
}
