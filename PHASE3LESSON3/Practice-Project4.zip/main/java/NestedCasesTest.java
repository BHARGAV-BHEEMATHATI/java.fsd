import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class NestedCasesTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    @Nested
    @DisplayName("Addition tests")
    class AdditionTests {
        @Test
        @DisplayName("Addition of positive numbers")
        void testAdditionPositiveNumbers() {
            int result = calculator.add(2, 3);
            System.out.println("Result of addition of positive numbers: " + result);
            assertEquals(5, result);
        }

        @Test
        @DisplayName("Addition of negative numbers")
        void testAdditionNegativeNumbers() {
            int result = calculator.add(-2, 1);
            System.out.println("Result of addition of negative numbers: " + result);
            assertEquals(-1, result);
        }
    }

    @Nested
    @DisplayName("Subtraction tests")
    class SubtractionTests {
        @Test
        @DisplayName("Subtraction of positive numbers")
        void testSubtractionPositiveNumbers() {
            int result = calculator.subtract(5, 2);
            System.out.println("Result of subtraction of positive numbers: " + result);
            assertEquals(3, result);
        }

        @Test
        @DisplayName("Subtraction of negative numbers")
        void testSubtractionNegativeNumbers() {
            int result = calculator.subtract(-2, 3);
            System.out.println("Result of subtraction of negative numbers: " + result);
            assertEquals(-5, result);
        }
    }
}
