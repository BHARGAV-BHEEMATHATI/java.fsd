import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIfEnvironmentVariable;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ConditionalTests {

    @Test
    @EnabledOnOs(OS.WINDOWS)
    void testOnWindows() {
        String osName = System.getProperty("os.name").toLowerCase();
        System.out.println("Operating System: " + osName);
        assertTrue(osName.contains("windows"), "Expected Windows operating system");
    }

    @Test
    @DisabledIfEnvironmentVariable(named = "ENV", matches = "staging-server")
    void testDisabledOnStagingServer() {
        // Test that should be disabled if running on a staging server
    }

    @Test
    @DisabledIfSystemProperty(named = "ci-server", matches = "true")
    void testDisabledOnCiServer() {
        // Test that should be disabled if running on a CI server
    }
}
