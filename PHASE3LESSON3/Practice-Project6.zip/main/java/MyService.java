public class MyService {
    public String doSomething() {
        return "Hello from MyService!";
    }
}
