import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MyExtension.class)
public class DependencyInjectionTest {

    private final MyService myService;

    public DependencyInjectionTest(MyService myService) {
        this.myService = myService;
    }

    @Test
    void testDependencyInjection() {
        assertNotNull(myService);
        myService.doSomething();
    }
}
