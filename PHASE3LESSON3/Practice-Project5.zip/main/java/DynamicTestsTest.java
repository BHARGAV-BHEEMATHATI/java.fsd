import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

public class DynamicTestsTest {

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                dynamicTest("First dynamic test", () -> {
                    System.out.println("Executing first dynamic test...");
                    assertTrue(true);
                }),
                dynamicTest("Second dynamic test", () -> {
                    System.out.println("Executing second dynamic test...");
                    assertTrue(2 > 1);
                })
        );
    }
}
