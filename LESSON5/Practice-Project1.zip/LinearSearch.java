import java.util.Scanner;
public class LinearSearch {

    // Function to perform linear search
    static int linearSearch(int[] arr, int target) {
        int n = arr.length;

        for (int i = 0; i < n; i++) {
            if (arr[i] == target) {
                return i; // Target found, return the index
            }
        }

        return -1; // Target not found
    }

    public static void main(String[] args) {
        int[] array = {4, 2, 8, 1, 6, 3, 7, 9, 5};
        
        Scanner sc=new Scanner(System.in);
        System.out.println("enter which value need to search:");
        int target = sc.nextInt();

        int result = linearSearch(array, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }
}