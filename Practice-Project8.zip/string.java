package strings;

public class string {
	

	    public static void main(String[] args) {
	        // Create a string
	        String originalString = "Hello, World!";
	        
	        // Display the original string
	        System.out.println("Original String: " + originalString);
	        
	        
	        // Convert string to StringBuffer
	        StringBuffer sb = new StringBuffer(originalString);
	        
	        // Display the StringBuffer conversion
	        System.out.println("StringBuffer Conversion: " + sb);

	        
	        
	        // Convert string to StringBuilder
	        StringBuilder sr = new StringBuilder(originalString);

	        // Display the StringBuilder conversion
	        System.out.println("StringBuilder Conversion: " + sr);
	        

	        //sub string
	        String substring = originalString.substring(7, 12);
	        System.out.println("Substring (7-12): " + substring);

	        //upper case
	        String upperCase = originalString.toUpperCase();
	        System.out.println("Uppercase: " + upperCase);

	        //lower case
	        String lowerCase = originalString.toLowerCase();
	        System.out.println("Lowercase: " + lowerCase);

	        //replace
	        String replacedString = originalString.replace('o', 'x');
	        System.out.println("String after replacing 'o' with 'x': " + replacedString);
	    }
	}


