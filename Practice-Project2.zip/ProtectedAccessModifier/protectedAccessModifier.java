package modifiers;

public class protectedAccessModifier {
	    protected int protectedVariable = 40;

	    protected void protectedMethod() {
	        System.out.println("Protected Method");
	        System.out.println("the protected variable is:"+protectedVariable);
	    }
	}

