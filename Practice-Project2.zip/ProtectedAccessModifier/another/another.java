package another;

public class another {
	 public static void main(String[] args) {
	       // proctecteAccessdModifier obj = new  proctecteAccessdModifier();
	        //obj.protecteddMethod();
	        // protectedVariable and protectedMethod have protected access  and are not accessible from a different package without subclassing.

}
}