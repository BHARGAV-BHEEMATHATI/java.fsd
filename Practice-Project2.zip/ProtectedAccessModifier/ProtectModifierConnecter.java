package modifiers;

public class ProtectModifierConnecter extends protectedAccessModifier {
	       public static void main(String[] args) {
	    	   protectedAccessModifier  obj = new protectedAccessModifier ();
	           obj.protectedMethod();  // Accessing protected method
	       }
	   }
