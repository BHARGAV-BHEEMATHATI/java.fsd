package modifiers;

    class PrivateDemoClass {
    // Private variable
    private int privateNumber = 10;
    
    // Private method
    private void displayPrivateNumber() {
        System.out.println("Private Number: " + privateNumber);
    }
    }
    //  method to access the public method
       class performPrivate {
    	public int a=4,b=6,c=a+b;
        public void display() {
        	System.out.println("this is public class ");
        	System.out.println("sum of a and b is:"+c);
        }
    }
      //main 
      public  class PrivateAccessModifier{
        public static void main(String[] args) {
        
        performPrivate obj =new performPrivate();
        obj.display();
        PrivateDemoClass objnew=new PrivateDemoClass();
     // objnew.displayPrivateNumber(); 
         //Accessing privateNumber will result in a compilation error,because the private variables does not accessible in another class 
      
    }
 }
