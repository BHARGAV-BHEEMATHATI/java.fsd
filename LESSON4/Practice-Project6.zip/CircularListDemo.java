class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    // Function to insert a new element into the sorted circular linked list
    void insert(int newData) {
        Node newNode = new Node(newData);
        Node current = head;

        // If the list is empty, make the new node the head and point it to itself
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (newData < head.data) {
            // If the new element is smaller than the head, insert it at the beginning
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
            // Traverse the list to find the correct position to insert the new element
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }

            // Insert the new element at the correct position
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to print the elements of the circular linked list
    void display() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}  
    public class CircularListDemo {

    public static void main(String[] args) {
        SortedCircularLinkedList sortedList = new SortedCircularLinkedList();

        // Inserting elements into the sorted circular linked list
        sortedList.insert(10);
        sortedList.insert(20);
        sortedList.insert(30);
        sortedList.insert(15);
        sortedList.insert(1);

        // Displaying the sorted circular linked list
        System.out.println("Sorted Circular Linked List:");
        sortedList.display();
    }
 }

