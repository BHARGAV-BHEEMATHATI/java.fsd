
import java.util.Arrays;

public class FourthSmallestElement 
{
	 // Function to find the fourth smallest element in an unsorted list
    private static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("The array has less than 4 elements.");
            return -1; // Return a sentinel value indicating an error
        }
    
        // Sort the array in ascending order
        Arrays.sort(arr);

        // Return the fourth element (index 3) in the sorted array
        return arr[3];
    }
    public static void main(String[] args) {
        // unsorted list
        int[] unsortedList = {10, 5, 8, 1, 7, 3, 9, 2, 6, 4};

        // Find the fourth smallest element
        int fourthSmallest = findFourthSmallest(unsortedList);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

   
}