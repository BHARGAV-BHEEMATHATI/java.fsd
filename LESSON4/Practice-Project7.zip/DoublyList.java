class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    // Function to insert a new node at the end of the doubly linked list
    void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }

    // Function to traverse the doubly linked list in the forward direction
    void forwardTraversal() {
        Node current = head;
        System.out.println("Forward Traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Function to traverse the doubly linked list in the backward direction
    void backwardTraversal() {
        Node current = head;
        while (current != null && current.next != null) {
            current = current.next;
        }

        System.out.println("Backward Traversal:");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
   public class DoublyList{
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        // Inserting elements into the doubly linked list
        doublyList.insert(10);
        doublyList.insert(20);
        doublyList.insert(30);

        // Performing forward traversal
        doublyList.forwardTraversal();

        // Performing backward traversal
        doublyList.backwardTraversal();
    }
}
}
