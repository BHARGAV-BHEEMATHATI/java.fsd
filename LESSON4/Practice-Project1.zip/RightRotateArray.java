package array;

public class RightRotateArray
{

    // Function to print an array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
	 // Function to reverse an array in the given range [start, end]
    private static void reverseArray(int[] arr, int start, int end)
    {
        while (start < end) 
        {
            // Swap elements at start and end indices
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;

            // Move indices towards the center
            start++;
            end--;
        }
    }

	 // Function to right rotate an array by 'steps' steps
    private static void rightRotateArray(int[] arr, int steps)
    {
        int n = arr.length;
        steps = steps % n; // To handle cases where steps are greater than array length

        reverseArray(arr, 0, n - 1);
        reverseArray(arr, 0, steps - 1);
        reverseArray(arr, steps, n - 1);
    }

   
	    public static void main(String[] args) {
	        //  array initialization
	        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};

	        // Number of steps to right rotate
	        int steps = 5;

	        System.out.println("Original Array:");
	        printArray(array);

	        // Right rotate the array
	        rightRotateArray(array, steps);

	        System.out.println("\nArray after right rotation by " + steps + " steps:");
	        printArray(array);
	    }

	   
	}
