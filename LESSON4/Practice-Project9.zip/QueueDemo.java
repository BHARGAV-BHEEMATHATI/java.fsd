import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
    public static void main(String[] args) {
        // Creating a queue
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        System.out.println("Enqueue elements into the queue:");
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);

        // Displaying the queue after enqueuing elements
        System.out.println("Queue after enqueuing elements: " + queue);

        // Dequeue elements from the queue
        System.out.println("\nDequeue elements from the queue:");
        while (!queue.isEmpty()) {
            int dequeuedElement = queue.poll();
            System.out.println("Dequeued element: " + dequeuedElement);
        }

        // Displaying the queue after dequeuing elements
        System.out.println("\nQueue after dequeuing elements: " + queue);
    }
}
