import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue (insert) elements into the queue
        enqueue(queue, 10);
        enqueue(queue, 20);
        enqueue(queue, 30);
        enqueue(queue, 40);

        // Display the queue after enqueuing elements
        displayQueue(queue);

        // Dequeue (remove) elements from the queue
        dequeue(queue);
        dequeue(queue);

        // Display the queue after dequeuing elements
        displayQueue(queue);
    }

    // Enqueue method to insert elements into the queue
    private static void enqueue(Queue<Integer> queue, int element) {
        queue.offer(element);
        System.out.println("Enqueued: " + element);
    }

    // Dequeue method to remove elements from the queue
    private static void dequeue(Queue<Integer> queue) {
        if (!queue.isEmpty()) {
            int dequeuedElement = queue.poll();
            System.out.println("Dequeued: " + dequeuedElement);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }

    // Display the elements in the queue
    private static void displayQueue(Queue<Integer> queue) {
        System.out.println("Queue: " + queue);
    }
}
