package exception;

	import java.util.Scanner;

	public class ExceptionHandling 
	{
		private static int divideNumbers(int numerator, int denominator)
		{
	        // Division operation 
	        return numerator / denominator;
	    }
	    public static void main(String[] args) 
	    {
	        Scanner scanner = new Scanner(System.in);

	        try 
	        {
	            System.out.print("Enter a numerator: ");
	            int numerator = scanner.nextInt();

	            System.out.print("Enter a denominator: ");
	            int denominator = scanner.nextInt();

	            int result = divideNumbers(numerator, denominator);
	            System.out.println("Result of division: " + result);
	        } 
	        catch (ArithmeticException e)
	        {
	            System.out.println("Error: Division by zero is not allowed.");
	        }
	        
	        catch (Exception e) 
	        {
	            System.out.println("An unexpected error occurred: " + e.getMessage());
	        } 
	        finally
	        {
	            // Close resources or perform cleanup code
	            scanner.close();
	            System.out.println("Program execution completed.");
	        }
	    }

	}    