interface GreetFirst {
    default void greet() {
        System.out.println("Hello from GreetFirst!");
    }
}

interface GreetSecond {
    default void greet() {
        System.out.println("Hello from GreetSecond!");
    }
}

class GreetingClass implements GreetFirst, GreetSecond {
    @Override
    public void greet() {
        GreetFirst.super.greet(); // Calling the default method from GreetFirst
        GreetSecond.super.greet(); // Calling the default method from GreetSecond
        System.out.println("Custom Greeting!");
    }
}

public class DiamondProblem {

    public static void main(String[] args) {
        GreetingClass greetingObj = new GreetingClass();
        greetingObj.greet();
    }
}