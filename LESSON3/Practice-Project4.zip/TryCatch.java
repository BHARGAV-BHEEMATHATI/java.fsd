package TRyAndCatch;
	import java.util.Scanner;
	
	
	
	public class TryCatch {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        try {
	            
	            System.out.print("Enter a number: ");
	            int number = sc.nextInt();

	            //  perform division
	            int result = 10 / number;

	            // If no exception occurs
	            System.out.println("Result of division: " + result);
	        } 
	        
	        catch (ArithmeticException e) {
	            // Catch block for ArithmeticException
	            System.out.println("Error: Cannot divide by zero.");
	            
	        } 
	        
	        catch (java.util.InputMismatchException e) {
	            // Catch block for InputMismatchException
	            System.out.println("Error: Please enter a valid number.");
	        } 
	        finally {
	            // Finally block 
	            System.out.println("Finally block executed.");
	            sc.close();
	        }
	    }
	}