package MyThread;
  
class MyRunnable implements Runnable{
	public void run() {
		System.out.println("thread begins");
		for(int i=1;i<=5;i++) {
			System.out.println(" thread begin"+" "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		System.out.println("Thread End");
	}
}
public class Runnable1 {

	public static void main(String[] args) {
		//creating object  for MyRunnable 
		MyRunnable mr=new MyRunnable();
       // creating Thread
		Thread t1=new Thread(mr);
		
		t1.start();
		
		
	}

}
