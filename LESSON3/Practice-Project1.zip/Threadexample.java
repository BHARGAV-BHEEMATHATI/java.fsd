package MyThread;
class myThread extends Thread{
	public void run() {
		for(int i=1;i<=5;i++) {
			
		System.out.println("thread started"+" "+i);
		
	}
		System.out.println("-------------------------");
 }
	
}
public class Threadexample  {
public static void main(String args[]) {
	myThread t1= new myThread();
	t1.start();
 }
}