package Synchronization;

class BankAccount {
    public int balance =2000; // Initial balance

    // Synchronized method to withdraw money
    public synchronized void withdraw(int amount) {
        if (amount > 0 && amount <= balance) {
            
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            balance=balance- amount;
            System.out.println(Thread.currentThread().getName() + " withdrew $" + amount + ". Remaining balance: $" + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " cannot withdraw. Insufficient funds.");
        }
    }

	public int getBalance() {
		
		return balance;
	}
}

class WithdrawThread extends Thread {
    private BankAccount account;
    private int amount;

    public WithdrawThread(BankAccount account, int amount) {
        this.account = account;
        this.amount = amount;
    }

    public void run() {
        account.withdraw(amount);
    }
}

public class synchro {
    public static void main(String[] args) throws InterruptedException {
        BankAccount account = new BankAccount();

        WithdrawThread thread1 = new WithdrawThread(account, 500);
        WithdrawThread thread2 = new WithdrawThread(account, 800);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();

        System.out.println("Final Balance: $" + account.getBalance());
    }
  }

