
class MySleepWait extends Thread {
	private final Object lock;

    MySleepWait(Object lock) {
        this.lock = lock;
    }
	public void run() {
		for(int i=1;i<=5;i++) {;
			
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} 
			catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}
}

public class WaitSleep {
	   
	    public static void main(String args[]) throws InterruptedException
	    
	    {
	    	 Object lock = new Object();
	    	 MySleepWait sw = new MySleepWait(lock);
	    	 
	    	 synchronized (lock) {
	             System.out.println("main thread is starting");
	             Thread.sleep(1000);
	             sw.start();
	             lock.wait(5000);
	             System.out.println("Main thread is woken after waiting for 6 seconds");
	    }
	    
  }
	    
}


