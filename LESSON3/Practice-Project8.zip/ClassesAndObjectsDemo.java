package oops;
//Define a class named 'Person'
class Person {
 // Instance variables
 String name;
 int age;

 // Constructor to initialize the object
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Method to display information about the person
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}

public class ClassesAndObjectsDemo {

 public static void main(String[] args) {
     // Create objects of the 'Person' class
     Person person1 = new Person("John", 25);
     Person person2 = new Person("Jane", 30);

     // Call methods on the objects
     System.out.println("Information about Person 1:");
     person1.displayInfo();

     System.out.println("\nInformation about Person 2:");
     person2.displayInfo();
 }
}