package oops;

abstract class Vehicle {
 abstract void start();

 void stop() {
     System.out.println("Vehicle is stopping");
 }
}

class Car extends Vehicle {
 @Override
 void start() {
     System.out.println("Car is starting");
 }

 void drive() {
     System.out.println("Car is in motion");
 }
}

class Motorcycle extends Vehicle {
 @Override
 void start() {
     System.out.println("Motorcycle is starting");
 }

 void ride() {
     System.out.println("Motorcycle is on the road");
 }
}

public class AbstractClassExample {

 public static void main(String[] args) {
     Vehicle car = new Car();
     Vehicle motorcycle = new Motorcycle();

     car.start();
     car.stop();

     motorcycle.start();
     motorcycle.stop();

     ((Car) car).drive();
     ((Motorcycle) motorcycle).ride();
 }
}