package Throw;
import java.io.FileNotFoundException;


public class Throws
{
	 private static void readFile(String fileName) throws FileNotFoundException 
	    {
	        // method that may throw a checked exception
	        throw new FileNotFoundException("File not found: " + fileName);
	    }
	
	    public static void main(String[] args)
	    {
	        try
	        {
	            readFile("example.txt");
	        } 
	        catch (FileNotFoundException e)
	        {
	            System.out.println("Caught FileNotFoundException: " + e.getMessage());
	        }
	    }

}	   