package Throw;

public class Finally
{
	  private static int divide(int numerator, int denominator) 
	  {
	        if (denominator == 0)
	        {
	            throw new ArithmeticException("Cannot divide by zero.");
	        }
	        else 
	        {
	        return numerator / denominator;
	        }
	    }
	
	    public static void main(String[] args) 
	    {
	        try 
	        {
	            int result = divide(10, 2);
	            System.out.println("Result: " + result);
	        } 
	        catch (ArithmeticException e)
	        {
	            System.out.println("Caught ArithmeticException: " + e.getMessage());
	        } finally
	        {
	            System.out.println("finally block");
	        }
	    }
}