package Throw;

	class CustomException extends Exception
	{
	    public CustomException(String message)
	    {
	        super(message);
	    }
	}

	public class CustomExceptions 
	{
	    public static void main(String[] args)
	    {
	        try
	        {
	            validateInput(20);
	        } 
	        catch (CustomException e) 
	        {
	            System.out.println("Caught CustomException: " + e.getMessage());
	        }
	    }

	    private static void validateInput(int value) throws CustomException 
	    {
	        if (value < 0) 
	        {
	            throw new CustomException("Input value cannot be negative.");
	        }
	        else
	        {
	        System.out.println("Input is valid.");
	    }
	}
}