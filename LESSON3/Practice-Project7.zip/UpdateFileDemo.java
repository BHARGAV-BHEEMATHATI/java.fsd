package file;
	import java.io.FileWriter;
	import java.io.IOException;

	public class UpdateFileDemo {
		private static void updateFile(String filePath, String newContent) {
	        try (FileWriter writer = new FileWriter(filePath)) {
	            writer.write(newContent);
	            System.out.println("File updated with new content.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }
		}
	    public static void main(String[] args) {
	        // Specify the file path
	        String filePath = "example.txt";

	        // Update data in the file
	        updateFile(filePath, "Updated content!");
	    }

	   }    