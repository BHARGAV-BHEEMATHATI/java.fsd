package file;
	import java.io.File;
	import java.io.IOException;

	public class CreateFileDemo 
	{
		 private static void createFile(String filePath)
		 {
		        try 
		        {
		            File file = new File(filePath);

		            if (file.createNewFile())
		            {
		                System.out.println("File created: " + file.getName());
		            }
		            else 
		            {
		                System.out.println("File already exists.");
		            }
		        } 
		        catch (IOException e) 
		        {
		            System.out.println("An error occurred while creating the file.");
		            e.printStackTrace();
		        }
		    }
	    public static void main(String[] args)
	    {
	        
	        String filePath = "example.txt";

	        // Create a new file
	        createFile(filePath);
	    }

	   
	}