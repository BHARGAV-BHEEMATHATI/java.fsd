package file;
import java.io.File;

public class DeleteFileDemo {
	private static void deleteFile(String filePath) {
        File file = new File(filePath);

        if (file.delete()) {
            System.out.println("File deleted: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "example.txt";

        // Delete the file
        deleteFile(filePath);
    }

    
}